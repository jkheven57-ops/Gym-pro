# GymPro — gerar APK pelo GitHub

1. Crie um repositório no GitHub.
2. Envie `GymPro_v1_recriado.zip` para a raiz do repositório.
3. Crie o arquivo `.github/workflows/build.yml` e cole o conteúdo deste pacote.
4. Abra a aba **Actions** → **Build GymPro APK** → **Run workflow**.
5. Quando terminar, abra a execução concluída → **Artifacts** → `GymPro-APK`.
6. Baixe o APK no celular e instale.

O workflow usa Flutter 3.47.5 estável e gera `app-release.apk`.
